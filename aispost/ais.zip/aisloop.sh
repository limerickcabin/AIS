while : 
do
	./ais.sh
done
