while :
do
	python aispost.py
done
