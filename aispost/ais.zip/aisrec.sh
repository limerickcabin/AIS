while :
do
	sudo rtl_ais -R on -n
done
